/*
 * Title : ImageUtil.java
 * Purpose  : All the functions related to image like..
 * 			->Image to bufferedimage
 * 			->Resizing Bufferdimage
 * 			->Converting square shape image to round shape
 * Reference : https://stackoverflow.com/
 */
package collegeapplication.common;

import java.awt.*;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.*;
import java.io.IOException;

import javax.swing.*;

@SuppressWarnings("unused")
public class ImageUtil {

    // Converts an Image to a BufferedImage
	public static BufferedImage toBufferedImage(Image image) {
	    if (image == null) {
	        throw new IllegalArgumentException("Image cannot be null.");
	    }

	    // Ensure the image is fully loaded
	    ensureImageLoaded(image);

	    // Validate image dimensions
	    int width = image.getWidth(null);
	    int height = image.getHeight(null);
	    if (width <= 0 || height <= 0) {
	        throw new IllegalArgumentException("Invalid image dimensions: width=" + width + ", height=" + height);
	    }

	    // Check if the image has alpha transparency
	    boolean hasAlpha = hasAlpha(image);

	    // Create a buffered image compatible with the screen
	    BufferedImage bimage = null;
	    GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();

	    try {
	        int transparency = hasAlpha ? Transparency.BITMASK : Transparency.OPAQUE;
	        GraphicsDevice gs = ge.getDefaultScreenDevice();
	        GraphicsConfiguration gc = gs.getDefaultConfiguration();
	        bimage = gc.createCompatibleImage(width, height, transparency);
	    } catch (HeadlessException e) {
	        System.err.println("HeadlessException: Falling back to default color model.");
	    }

	    if (bimage == null) {
	        int type = hasAlpha ? BufferedImage.TYPE_INT_ARGB : BufferedImage.TYPE_INT_RGB;
	        bimage = new BufferedImage(width, height, type);
	    }

	    // Copy the image to the buffered image
	    Graphics g = bimage.createGraphics();
	    g.drawImage(image, 0, 0, null);
	    g.dispose();

	    return bimage;
	}

    
    // check if image is loaded
    public static void ensureImageLoaded(Image image) {
        if (image == null) {
            throw new IllegalArgumentException("Image cannot be null.");
        }

        MediaTracker tracker = new MediaTracker(new Component() {});
        tracker.addImage(image, 0);
        try {
            tracker.waitForID(0);
            if (tracker.isErrorID(0)) {
                throw new IOException("Image loading failed or image is invalid.");
            }
        } catch (InterruptedException | IOException e) {
            throw new RuntimeException("Failed to load image: " + e.getMessage(), e);
        }
    }

    // Checks if an image has an alpha channel
    public static boolean hasAlpha(Image image) {
        if (image == null) {
            throw new IllegalArgumentException("Image cannot be null");
        }

        if (image instanceof BufferedImage) {
            return ((BufferedImage) image).getColorModel().hasAlpha();
        }

        PixelGrabber pg = new PixelGrabber(image, 0, 0, 1, 1, false);
        try {
            pg.grabPixels();
        } catch (InterruptedException e) {
            System.err.println("PixelGrabber was interrupted: " + e.getMessage());
            return false;
        }

        ColorModel cm = pg.getColorModel();
        if (cm == null) {
            System.err.println("PixelGrabber could not retrieve ColorModel. Assuming no alpha.");
            return false;
        }

        return cm.hasAlpha();
    }

    // Resizes an image
    public static BufferedImage resizeImage(final Image image, int width, int height) {
        if (image == null) {
            throw new IllegalArgumentException("Image cannot be null.");
        }
        if (width <= 0 || height <= 0) {
            throw new IllegalArgumentException("Width and height must be positive integers.");
        }

        final BufferedImage bufferedImage = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        final Graphics2D graphics2D = bufferedImage.createGraphics();
        graphics2D.setComposite(AlphaComposite.Src);

        // Apply rendering hints for quality
        graphics2D.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
        graphics2D.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
        graphics2D.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        graphics2D.drawImage(image, 0, 0, width, height, null);
        graphics2D.dispose();
        return bufferedImage;
    }

    // Creates a rounded corner image
    public static BufferedImage makeRoundedCorner(BufferedImage image, int cornerRadius) {
        if (image == null) {
            throw new IllegalArgumentException("Image cannot be null.");
        }
        if (cornerRadius < 0) {
            throw new IllegalArgumentException("Corner radius must be non-negative.");
        }

        int w = image.getWidth();
        int h = image.getHeight();
        BufferedImage output = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);

        Graphics2D g2 = output.createGraphics();
        g2.setComposite(AlphaComposite.Src);
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setColor(Color.WHITE);
        g2.fill(new RoundRectangle2D.Float(0, 0, w, h, cornerRadius, cornerRadius));

        g2.setComposite(AlphaComposite.SrcAtop);
        g2.drawImage(image, 0, 0, null);

        g2.dispose();

        return output;
    }
}
